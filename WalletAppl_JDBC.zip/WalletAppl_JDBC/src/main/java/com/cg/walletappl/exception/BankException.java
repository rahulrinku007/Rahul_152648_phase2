package com.cg.walletappl.exception;

@SuppressWarnings("serial")
public class BankException extends Exception {
public BankException(String msg) {
	super(msg);
}
}
